#!/bin/bash
# golfzon PMK

GRadarDLL=0
GRadarDLL=`file /home/pi/GRadarM/GRadarM-0.1.1.Debug.out|grep -i "error"|gawk -F" " '{print $2}'` 

if [ -z "$GRadarDLL" ] && [ -e /home/pi/GRadarM/GRadarM-0.1.1.Debug.out ] ; then
 GRadarDLL=0
 GRadarDLL=`file /home/pi/GRadarM/GRadarM-0.1.1.Debug.out|grep -i "empty"|gawk -F" " '{print $2}'` 
 if [ -z "$GRadarDLL" ] ; then
  echo "GRadarDLL is valid[current file backup]" 
  sudo cp /home/pi/GRadarM/GRadarM-0.1.1.Debug.out /home/pi/test/GRadarM-0.1.1.Debug.out
 else
  echo "GRadarDLL is not valid[Empty,OLD File roll back]"
  sudo rm -rf /home/pi/GRadarM/GRadarM-0.1.1.Debug.out
  sudo cp /home/pi/test/GRadarM-0.1.1.Debug.out /home/pi/GRadarM/GRadarM-0.1.1.Debug.out
  sudo chmod 777 /home/pi/GRadarM/GRadarM-0.1.1.Debug.out
 fi 
else
 echo "GRadarDLL is not valid[File Error,OLD File roll back]" 
 sudo rm -rf /home/pi/GRadarM/GRadarM-0.1.1.Debug.out
 sudo cp /home/pi/test/GRadarM-0.1.1.Debug.out /home/pi/GRadarM/GRadarM-0.1.1.Debug.out
 sudo chmod 777 /home/pi/GRadarM/GRadarM-0.1.1.Debug.out
fi
