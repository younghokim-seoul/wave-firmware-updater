sudo /home/pi/test/e6/E6Client -v | gawk 'NR == 1 {print $4}'
