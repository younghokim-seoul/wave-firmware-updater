#!/bin/bash
# 2023.06.28 PMK , phase config

# sensor distance 
par1=$1
# reference w degree 
par2=$2
# reference h degree 
par3=$3 

echo "par1,2,3:" $par1 $par2 $par3

sudo echo $par1 > /home/pi/test/fRadiousFile.txt 
sleep 1
sudo echo $par3 $par2 > /home/pi/test/experiment.txt 

cat /home/pi/test/fRadiousFile.txt 
cat /home/pi/test/experiment.txt 