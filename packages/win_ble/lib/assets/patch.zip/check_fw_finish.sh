
#!/bin/bash
# golfzon PMK

DGFW=/home/upgrade/DigitalBoard/DBfirmware.dfu

#check fw download is finished
GE=0
GE=`sed -n '/100%/{p;q}' /home/pi/test/fw_down.log`
echo "check_fw_finish"
echo $GE

if [ -z "$GE" ] ; then
 echo "not finished" 
 echo 1 > /home/pi/test/fw_finish.log
else
 echo "finished" 
 echo 0 > /home/pi/test/fw_finish.log
 sudo cp $DGFW /home/pi/test/DBfirmware.dfu
 sleep 1
 rm -rf $DGFW
fi
