#!/bin/bash

# golfzon pmk [2018.09.06]
# digital board(stm32f) firmware download 

FILE=$1
COUNT1=0
UNTIL=10

# STEP1 : FW File check(???())
if [ -f "$FILE" ]; then
 echo "FW File Check[ok]"
 sudo /home/pi/test/test_fwdown $FILE
 sleep 3
 echo 1 > /home/pi/test/fw_finish.log
 sudo rm -rf /home/pi/test/fw_down.log
else 
 echo "file not exist!!! or file name is wrong" 
 exit 0
fi  

# STEP2 : Wait 5 second until detect STM DUT  
while [ $COUNT1 -ne $UNTIL ]
 do 
  USBis=`lsusb | grep -i "STM" | gawk -F" " '{printf $8}'`    
  if [ "$USBis" == "STM" ]; then
   VEN=`lsusb | grep -i "STM" | gawk -F" " '{printf $6}' | gawk -F":" '{print $1}'`
   PRO=`lsusb | grep -i "STM" | gawk -F" " '{printf $6}' | gawk -F":" '{print $2}'`
   if [ "$VEN" == "0483" ] && [ "$PRO" == "df11" ]; then
    COUNT1=10
    echo "found STM DFU $FILE"
    sudo dfu-util -a 0 -D $FILE | tee /home/pi/test/fw_down.log
	sleep 7
    # check finished 
    sudo /home/pi/test/check_fw_finish.sh 	
    echo "DB Reset!!!" 
    #sudo /home/pi/test/test_dbrst
    sudo /home/pi/test/db_hwrst
    sudo /home/pi/test/usb_reset.sh	
    exit 0
   fi
  else
   COUNT1=$(($COUNT1+1)) 
   echo "[FW_DOWN]Check STM DUT[$COUNT1]"
  fi 
 sleep 0.5
 done 

 echo "STM is Not founded [$VEN $PRO]" 
exit 0 



