#!/bin/bash

echo "$0 start"

UPGRADEFILE=/home/upgrade/GRadar_DLL/GRadarM-0.1.1.Debug.out
NEWFILE=/home/pi/GRadarM/GRadarM-0.1.1.Debug.out
OLDFILE=/home/pi/GRadarM/GRadarM-0.1.1.Debug_old.out

if [ -f "$UPGRADEFILE" ] ; then
	echo "File Founded $UPGRADEFILE"
    
    sudo /home/pi/test/kill_run_check_t.sh
    sleep 1 
    sudo /home/pi/test/kill_run_check_t.sh
    sleep 1 
    sudo /home/pi/test/kill_run_check_t.sh
    sleep 1 	
	sudo chmod 777 $UPGRADEFILE
	sudo chmod 777 $NEWFILE
	sudo mv $NEWFILE $OLDFILE
	sudo cp $UPGRADEFILE $NEWFILE
	sudo chmod 777 $NEWFILE
    sudo rm $UPGRADEFILE
else
	echo "File not found $NEWTOOLPOS"
fi

echo "$0 end"
