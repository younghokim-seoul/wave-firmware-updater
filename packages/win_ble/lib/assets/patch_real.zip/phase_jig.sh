#!/bin/bash
# 2023.06.13 PMK , phase jig 

#check exist task
GETpid=0
FILES=0
NUM=1
KILL="launch_jig"

COUNT=`ps -ef | grep -i $KILL | grep -v grep | wc -l`
GETpid=`ps -ef | grep -i $KILL | grep -v grep | gawk NR==$COUNT | gawk -F" " '{printf $2}'`

echo "start[$0 $KILL $COUNT $GETpid]"

if [ "$COUNT" == "$FILES" ]; then
 echo "not running !!![$0]"
else
 while [ $COUNT -ne $FILES ]
  do  
  echo "kill !!! $GETpid"
  kill -15 $GETpid
  sleep 1
  COUNT=`ps -ef | grep -i $KILL | grep -v grep | wc -l`
  GETpid=`ps -ef | grep -i $KILL | grep -v grep | gawk NR==$COUNT | gawk -F" " '{printf $2}'`
  echo "[$0 $KILL $COUNT $GETpid]"
  done 
fi
echo "end[$0]"

sleep 1 
sudo /home/pi/test/launch_jig &


