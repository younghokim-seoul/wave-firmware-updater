#!/bin/bash
# golfzon pmk [2022.06.03]
##  check cam running

sudo crontab -r
(crontab -l 2>/dev/null; echo "* * * * * sleep 10; /home/pi/bt/bt_check.sh >> /home/pi/bt/bt.log 2>&1") | crontab -

#e6 
#sudo mkdir /home/pi/test/e6
sudo cp /home/upgrade/GRadar_DLL/E6Client /home/pi/test/e6
sudo chmod 777 /home/pi/test/e6/*
sudo rm  /home/upgrade/GRadar_DLL/E6Client

#self test rpi 
sudo cp /home/upgrade/GRadar_DLL/test_result.conf /etc/rpimonitor/template
sudo chmod 777 /etc/rpimonitor/template/*
sudo rm /home/upgrade/GRadar_DLL/test_result.conf

sudo cp /home/upgrade/GRadar_DLL/ERR_CODE.html /home/pi/cam/www
sudo chmod 777 /home/pi/cam/www/*
sudo rm /home/upgrade/GRadar_DLL/ERR_CODE.html

#boot set
if [ -e /home/upgrade/GRadar_DLL/sun8i-h3-nanopi-neo-air.dtb ]; then
 DIF=0
 DIF=`diff -c /boot/sun8i-h3-nanopi-neo-air.dtb /home/upgrade/GRadar_DLL/sun8i-h3-nanopi-neo-air.dtb`
 if [ -z "$DIF" ] && [ -e /boot/sun8i-h3-nanopi-neo-air.dtb ] ; then
  sudo echo "same"
 else
  sudo echo "not same"
  sudo mv /boot/sun8i-h3-nanopi-neo-air.dtb /boot/sun8i-h3-nanopi-neo-air_old.dtb
  sudo cp /home/upgrade/GRadar_DLL/sun8i-h3-nanopi-neo-air.dtb /boot
  sudo chmod 777 /boot/*
  sudo rm /home/upgrade/GRadar_DLL/sun8i-h3-nanopi-neo-air.dtb
 fi 
fi 
 
#WIFI US SET 
check=0
check=`sed -n '/country/{p;q}' /etc/wpa_supplicant/wpa_supplicant.conf`
if [ -z "$check" ] ; then
 echo "WIFI US SET [NONE]"
 sed -i '1s/^/country=US\n/' /etc/wpa_supplicant/wpa_supplicant.conf
else
 echo "WIFI US SET " $check
 sed -i 's/country=../country=US/g' /etc/wpa_supplicant/wpa_supplicant.conf
fi

# change ble default mode 
sudo echo 1 > /home/pi/test/set_ble_mode.log


# add SetPosX value to limit ball range 
sudo /home/pi/test/set_posx_limit.sh 0.6 

# delete jig
sudo rm -rf /home/upgrade/GRadar_DLL/launch_jig


