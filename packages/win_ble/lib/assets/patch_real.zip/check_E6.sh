#!/bin/bash
# golfzon PMK

E6=0
#E6=`file /home/pi/test/e6/E6Client|grep -i "ELF 32-bit"`
E6=`file /home/pi/test/e6/E6Client|grep -i "error"|gawk -F" " '{print $2}'` 

if [ -z "$E6" ] ; then
 echo "E6 is valid" 
 E6=0
 E6=`diff -c /home/pi/test/e6/E6Client /home/pi/test/E6Client`
 if [ -z "$E6" ] && [ -e /home/pi/test/E6Client ] ; then
  sudo echo "E6 file is same"
 else
  sudo echo "E6 file is not same(copy)"
  sudo cp /home/pi/test/e6/E6Client /home/pi/test/E6Client
  sudo chmod 777 /home/pi/test/E6Client
 fi 
else
 echo "E6 is not valid" 
 #echo "$E6"
 sudo rm -rf /home/pi/test/e6/E6Client
 sudo cp /home/pi/test/E6Client /home/pi/test/e6/E6Client
 sudo chmod 777 /home/pi/test/e6/E6Client
fi
