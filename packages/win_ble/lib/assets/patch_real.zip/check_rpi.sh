# golfzon pmk [2022.06.07]
# selt test 

mDATE=$(date +%Y%m%d) 
mTIME=$(date +%H%M) 
mTIMEold=$(date +%H%M) 
mDATAold=$(date +%Y%m%d)

NETST=`netstat -tupn|grep 8888`

echo 0 > /home/pi/test/run_rpi.log
exit 1

if [ -z $NETST ]; then
        NETST=0 
        echo $NETST > /home/pi/test/run_rpi.log  
        #echo $NETST
        #echo "NETST1 0"
else
        mTIMEold=`cat /home/pi/test/run_rpi_t.log|gawk -F"," '{print $2}'`
	TIMEDIF=`echo "$mTIME - $mTIMEold"|bc`
        mDATEold=`cat /home/pi/test/run_rpi_t.log|gawk -F"," '{print $1}'` 
        DATEDIF=`echo "$mDATE - $mDATEold"|bc`
        #echo "mDATE,mDATEold: "$mDATE $mDATAold
        #echo "mTIME,mTIMEold: "$mTIME $mTIMEold
        #echo "DATEDIF: " $DATEDIF
        #echo "TIMEDIF: " $TIMEDIF
        if [ $DATEDIF -eq 0 ]; then
         if [ $TIMEDIF -lt 2 ]; then
	  NETST=0
          echo $NETST > /home/pi/test/run_rpi.log
          #echo "NETST2 0"
         else 
          NETST=1 
          echo $NETST > /home/pi/test/run_rpi.log
          echo "$mDATE,$mTIME" > /home/pi/test/run_rpi_t.log
          #echo "NETST3 1"
         fi
	else 
         NETST=1
         echo $NETST > /home/pi/test/run_rpi.log
         echo "$mDATE,$mTIME" > /home/pi/test/run_rpi_t.log
         #echo "NETST4 1"
        fi 
fi
