#!/bin/bash
#2023.05.18 PMK 

VAL=$1
sudo sed -i "s/<SetPosX>.<\/SetPosX>/<SetPosX>$VAL<\/SetPosX>/g" /home/pi/test/GRadar_Info_wave.xml
sudo sed -i "s/<SetPosX>..<\/SetPosX>/<SetPosX>$VAL<\/SetPosX>/g" /home/pi/test/GRadar_Info_wave.xml
sudo sed -i "s/<SetPosX>...<\/SetPosX>/<SetPosX>$VAL<\/SetPosX>/g" /home/pi/test/GRadar_Info_wave.xml
sudo sed -i "s/<SetPosX>....<\/SetPosX>/<SetPosX>$VAL<\/SetPosX>/g" /home/pi/test/GRadar_Info_wave.xml
sudo sed -i "s/<SetPosX>.....<\/SetPosX>/<SetPosX>$VAL<\/SetPosX>/g" /home/pi/test/GRadar_Info_wave.xml
sudo sed -i "s/<SetPosX>......<\/SetPosX>/<SetPosX>$VAL<\/SetPosX>/g" /home/pi/test/GRadar_Info_wave.xml
sudo sed -i "s/<SetPosX>.......<\/SetPosX>/<SetPosX>$VAL<\/SetPosX>/g" /home/pi/test/GRadar_Info_wave.xml
sudo sed -i "s/<SetPosX>........<\/SetPosX>/<SetPosX>$VAL<\/SetPosX>/g" /home/pi/test/GRadar_Info_wave.xml
sudo sed -i "s/<SetPosX>.........<\/SetPosX>/<SetPosX>$VAL<\/SetPosX>/g" /home/pi/test/GRadar_Info_wave.xml
sudo sed -i "s/<SetPosX>..........<\/SetPosX>/<SetPosX>$VAL<\/SetPosX>/g" /home/pi/test/GRadar_Info_wave.xml
sudo sed -i "s/<SetPosX>...........<\/SetPosX>/<SetPosX>$VAL<\/SetPosX>/g" /home/pi/test/GRadar_Info_wave.xml

sudo sed -i "s/<SetPosX>.<\/SetPosX>/<SetPosX>$VAL<\/SetPosX>/g" /GRadar_Info.xml
sudo sed -i "s/<SetPosX>..<\/SetPosX>/<SetPosX>$VAL<\/SetPosX>/g" /GRadar_Info.xml
sudo sed -i "s/<SetPosX>...<\/SetPosX>/<SetPosX>$VAL<\/SetPosX>/g" /GRadar_Info.xml
sudo sed -i "s/<SetPosX>....<\/SetPosX>/<SetPosX>$VAL<\/SetPosX>/g" /GRadar_Info.xml
sudo sed -i "s/<SetPosX>.....<\/SetPosX>/<SetPosX>$VAL<\/SetPosX>/g" /GRadar_Info.xml
sudo sed -i "s/<SetPosX>......<\/SetPosX>/<SetPosX>$VAL<\/SetPosX>/g" /GRadar_Info.xml
sudo sed -i "s/<SetPosX>.......<\/SetPosX>/<SetPosX>$VAL<\/SetPosX>/g" /GRadar_Info.xml
sudo sed -i "s/<SetPosX>........<\/SetPosX>/<SetPosX>$VAL<\/SetPosX>/g" /GRadar_Info.xml
sudo sed -i "s/<SetPosX>.........<\/SetPosX>/<SetPosX>$VAL<\/SetPosX>/g" /GRadar_Info.xml
sudo sed -i "s/<SetPosX>..........<\/SetPosX>/<SetPosX>$VAL<\/SetPosX>/g" /GRadar_Info.xml
sudo sed -i "s/<SetPosX>...........<\/SetPosX>/<SetPosX>$VAL<\/SetPosX>/g" /GRadar_Info.xml

echo "set_posx_limit.sh[Run]"