#!/bin/sh
# Golzon pmk

PATCH_ZIP=/home/upgrade/GRadar_DLL/patch.zip
UPDATE=/home/upgrade/GRadar_DLL
CHECK=0
NO="Noerrors"

CHECK=`unzip -t -P "GOLFZONWAVE" $PATCH_ZIP | grep "No errors"|gawk -F" " '{print $1$2}'`
echo "$CHECK"

if [ -z "$CHECK" ]; then
 echo "patch.zip is not valid"
 sudo echo 0 > /home/pi/test/check_patch.log
 
else
 echo "patch.zip is valid"
 sudo echo 1 > /home/pi/test/check_patch.log
fi 

