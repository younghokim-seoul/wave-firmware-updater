#!/bin/bash

# golfzon pmk [2018.09.14]
# NanoPi set RTC 

#echo "$0 start"

year=$1
mon=$2
day=$3
hour=$4
min=$5 
sec=$6 

if [ -z $1 ] || [ -z $2 ] || [ -z $3 ] || [ -z $4 ] || [ -z $5 ] || [ -z $6 ]  
	then
	echo "para error !!! year mon day hour min(*hour 24 format) "
	exit 0
fi 

#date -s "$1-$2-$3 $4:$5:30"
date -s "$1-$2-$3 $4:$5:$6" 

sleep 1
hwclock --localtime --systohc
#sleep 1

#check 
YEAR=`sudo date +"%Y %m %d %H %M" | gawk -F" " '{print $1}'`
MON=`sudo date +"%Y %m %d %H %M" | gawk -F" " '{print $2}'`
DAY=`sudo date +"%Y %m %d %H %M" | gawk -F" " '{print $3}'`
HOUR=`sudo date +"%Y %m %d %H %M" | gawk -F" " '{print $4}'`
MIN=`sudo date +"%Y %m %d %H %M" | gawk -F" " '{print $5}'`
#echo "get date" $YEAR $MON $DAY $HOUR $MIN 

if [ "$2" == "$MON" ]; then
 echo "MON same" 
else
 echo "MON not same"
 date -s "$1-$2-$3 $4:$5:$6"
 sleep 1
 hwclock --localtime --systohc
fi 
if [ "$3" == "$DAY" ]; then
 echo "DAY same" 
else
 echo "DAY not same"
 date -s "$1-$2-$3 $4:$5:$6"
 sleep 1
 hwclock --localtime --systohc
fi 
if [ "$4" == "$HOUR" ]; then
 echo "HOUR same" 
else
 echo "HOUR not same"
 date -s "$1-$2-$3 $4:$5:$6"
 sleep 1
 hwclock --localtime --systohc
fi 

#echo "$0 end"
