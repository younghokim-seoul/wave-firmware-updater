#!/bin/bash

# golfzon pmk [2020.09.08]
## delete file number limit count 

limit=400
count=0
Dir=/home/dbgftp/ShotDB1
File=/home/dbgftp/ShotDB1/ShotDB.tar

count=$(ls -ltr $Dir | grep "^-.*\.rbf" | wc -l)
echo "file total" $count

while [ $count -ge $limit ]
  do 
  count=$(ls -ltr $Dir | grep "^-.*\.rbf" | wc -l)
  del=$(ls -ltr $Dir | grep "^-.*\.rbf" | gawk NR==1 | gawk -F" " '{printf $9}')
  #echo "delete!!!" $del  
  sudo rm -rf $Dir/$del 
  done

#tar
#CTIME1=`date +%T | gawk -F":" '{print $1 $2 $3}'`
#echo $CTIME1 

#FILE_1=`date +%Y%M%D | gawk -F"/" '{print $1}'`
#FILE_2=`date +%T | gawk -F":" '{print $1 $2}'`
#FILE_3="$FILE_1"_"$FILE_2"
#echo $FILE_3

#FILE_4=`ls -ltr $Dir | gawk NR==2 | gawk -F" " '{printf $9}' | gawk -F"_" '{printf $2 $3}'`
#FILE_4=$(ls -ltr $Dir | grep .rbf | gawk NR==2 | gawk -F" " '{printf $9}' | gawk -F"_" '{printf $2$3}')
FILE_4=`ls -ltr $Dir | grep .rbf | gawk NR==1 | gawk -F" " '{printf $9}' | gawk -F"_" '{printf $2$3}'`
echo $FILE_4

sudo rm -rf $Dir/*.tar
	
if [ $count -gt 0 ] ; then
	#tar -cvzf $Dir/ShotDB1.tar $Dir/*.rbf
	#tar -cvf $Dir/ShotDB1.tar $Dir/*.rbf
	sudo tar -cf $Dir/$FILE_4.tar $Dir/*.rbf
	#sleep 1 
	sudo rm -rf $Dir/*.rbf
else
	echo "file nothing2"
fi

#CTIME2=`date +%T | gawk -F":" '{print $1 $2 $3}'`
#echo $CTIME2 
