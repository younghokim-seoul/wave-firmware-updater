#!/bin/bash

# golfzon pmk [2020.02.14]
## delete file number limit under 30  

limit=50
count=0
Dir=/home/dbgftp/Log1

count=$(ls -l $Dir | grep "^-.*\.log" | wc -l)
echo "file total" $count

while [ $count -ge $limit ]
  do 
  count=$(ls -l $Dir | grep "^-.*\.log" | wc -l)
  del=$(ls -ltr $Dir | grep "^-.*\.log" | gawk NR==1 | gawk -F" " '{printf $9}')
  #echo "delete!!!" $del  
  sudo rm -rf $Dir/$del 
  done

#tar
FILE_4=`ls -ltr $Dir | grep .log | gawk NR==1 | gawk -F" " '{printf $9}' | gawk -F"_" '{printf $2$3}'` 
echo $FILE_4 

rm -r $Dir/*.tar
	
if [ $count -gt 0 ] ; then
	tar -cf $Dir/$FILE_4.tar $Dir/*.log
	rm -rf $Dir/*.log
else
	echo "file nothing2"
fi

limit=100
count=0
Dir=/home/dbgftp/BT_Log1

count=$(ls -l $Dir | grep "^-.*\.log" | wc -l)
echo "file total" $count

while [ $count -ge $limit ]
  do 
  count=$(ls -l $Dir | grep "^-.*\.log" | wc -l)
  del=$(ls -ltr $Dir | grep "^-.*\.log" | gawk NR==1 | gawk -F" " '{printf $9}')
  #echo "delete!!!" $del  
  sudo rm -rf $Dir/$del 
  done

#tar
FILE5=`ls -ltr $Dir | grep .log | gawk NR==1 | gawk -F" " '{printf $9}' | gawk -F"_" '{printf $2$3}'` 
echo "File:" $FILE5 

rm -r $Dir/*.tar
	
if [ $count -gt 0 ] ; then
	tar -cf $Dir/$FILE5.tar $Dir/*.log
	rm -rf $Dir/*.log
else
	echo "file nothing2"
fi