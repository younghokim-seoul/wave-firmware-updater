sudo /home/pi/test/launch_jig -v | gawk 'NR == 1 {print $2}'
