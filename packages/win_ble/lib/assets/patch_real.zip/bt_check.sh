#!/bin/bash

bt_status=`hciconfig hci0 | gawk NR==3 | gawk -F" " '{print $1}'`
bt_down=DOWN

org1=`hciconfig | grep -i "BD Add" | gawk -F: '{print $3}'`
bta_err=AA

CTIME2=`date +%D_%T`

sudo /home/pi/test/wifi_check.sh
sudo /home/pi/test/detect_eth.sh
sudo /home/pi/test/check_cpu.sh
sudo /home/pi/test/check_DFU.sh

if [ $org1 == $bta_err ]
        then
        echo "[" $CTIME2 "]" "BT ADD run chg"
        sudo /home/pi/bt/bt_mac_1.sh
	org1=`hciconfig | grep -i "BD Add" | gawk -F: '{print $3}'`	
	if [ $org1 == $bta_err ]
		then
		echo "[" $CTIME2 "]" "BT CHG:Still Not"
	else
		echo "[" $CTIME2 "]" "BT CHG:" $bta_err "to" $org1	
        	sudo /home/pi/test/node_pmk.sh
	fi
else
	if [ $bt_status == $bt_down ] 
		then  
		echo "[" $CTIME2 "]" "BT STAT:" $bt_down
 		sudo /home/pi/bt/bt_config_on.sh
		sleep 1
        	#sudo /home/pi/bt/bt_mac_1.sh
		#sudo /home/pi/test/node_pmk.sh
        	bt_status=`hciconfig hci0 | gawk NR==3 | gawk -F" " '{print $1}'`
        	echo "BT run ON:" $bt_status 
	else
		echo "[" $CTIME2 "]" "BT STAT:" $bt_status
	fi 
fi
