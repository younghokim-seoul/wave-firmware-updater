﻿////////////////////////////////////////////////////////////////////
// 2019.02.19 
// PMK 수정 : GDR 연동을 위하여 TimeOut을 임시로 막아두자.나중에는 살려야..아니 js파일을 2가지로 사용하자 gradar_ble_to.js 

var util = require('util');
var bleno = require('./index');
var fs = require('fs'); 
var isPortReachable = require('is-port-reachable');
var net = require('net');
const path = require('path');

const logDir = '/home/dbgftp/BT_Log';
const logFilePattern = /\.log$/i;
const maxFileSize = 3 * 1024;


function deleteSmallLogFiles() {
  fs.readdir(logDir, (err, files) => {
    if (err) {
      console.error('Error reading log directory:', err);
      return;
    }

    files.forEach((file) => {
      if (logFilePattern.test(file)) {
        const filePath = path.join(logDir, file);
        const stats = fs.statSync(filePath);
        if (stats.size <= maxFileSize) {
          fs.unlinkSync(filePath);
          console.log('Deleted log file:', filePath);
        }
      }
    });
  });
}

deleteSmallLogFiles();


// log4js 
const log4js = require('log4js');
require('date-utils');
log4js.configure({
  appenders: { 
	out: { type: 'console' }, 
	//task: { type: 'dateFile', filename: 'task_', pattern: 'yyyyMMddhhmmss.log', alwaysIncludePattern: true } 
	task:{
	 type: 'multiFile', base: '/home/dbgftp/BT_Log/', property: 'userID',
	 extension: '.log', maxLogSize: 3000000, backups: 10, compress: true
 	} // 5242880(5MB) 
 },
  categories: { 
  default: { appenders: ['out','task'], level: 'info' },    // both log file and console 
  //default: { appenders: ['task'], level: 'info' },      // only log file 
	task: { appenders: ['task'], level: 'info'} 
  }
});
const logger4 = log4js.getLogger('console');
console.log = logger4.info.bind(logger4);
logger4.addContext('userID', /*new Date().toFormat('YYYYMMDD_HH24MISS')*/ 'BLE_'+GetTimeDate());
logger4.info('log4js start');

fs.exists("/home/pi/test/ble_mode.log", function(exists){
		if(exists){	
			fs.unlinkSync("/home/pi/test/ble_mode.log");	
		}
}); 


// date 
function GetTimeDate(){
  var x = new Date();
  var myVar1 = x.getMonth()+1;  
  var myVar2 = x.getDate();
  var myVar3 = x.getHours();
  var myVar4 = x.getMinutes();
  var myVar5 = x.getSeconds();
  var GetDate = '[' + myVar1+':'+myVar2+':'+myVar3+':'+myVar4+':'+myVar5 + ']';
  return x.toFormat('YYYYMMDD_HH24MISS');
}

function GetTimeDate_file(){
  var x = new Date();
  var myVar1 = x.getMonth()+1;  
  var myVar2 = x.getDate();
  var myVar3 = x.getHours();
  var myVar4 = x.getMinutes();
  var myVar5 = x.getSeconds();
  var GetDate = myVar1+'_'+myVar2+'_'+myVar3+'_'+myVar4+'_'+myVar5;
  return GetDate;
}

//logo 
var Console = require('console').Console; 
var output;
var logger;
//var output = fs.createWriteStream('/home/dbgftp/BT_Log/ble_'+GetDate+'.txt');
//var errout = fs.createWriteStream('/home/dbgftp/BT_Log/err_'+GetDate+'.txt');
//var logger = new Console(output,errout);
//var logger = new Console(output);

// bleno 
var BlenoPrimaryService = bleno.PrimaryService;
var BlenoCharacteristic = bleno.Characteristic;
var BlenoDescriptor = bleno.Descriptor;


console.log(/*GetTimeDate()+*/'[GRadar_BLE]bleno');
//logger.log(GetTimeDate()+'[GRadar_BLE]bleno:');
//console.log("process.memoryUsage()=",process.memoryUsage());


var _updateValueCallback = null;
//var _data = new Buffer(40);
var BLEConnected = false;


var Gradar_BLE;
var port=5999;
var port_avalilable=0;
var Gradar_Client;


function isPortAvailbleFunc(port){
    isPortReachable(port).then(reachable => {
    console.log(/*GetTimeDate()+*/'[BLE_SO]isPortReachable: '+port);
    //logger.log(GetTimeDate()+'[BLE_SO]isPortReachable: '+port);

    if(reachable==true)
    {
      port_avalilable=1;
      Gradar_BLE = getConnection("BLE");
      console.log(/*GetTimeDate()+*/'[BLE_SO]port_avalilable');
      //if(logger)  
        //logger.log(GetTimeDate()+'[BLE_SO]port_avalilable');
	
      return 1;
    }
    else
    {
      port_avalilable=0;
      console.log(/*GetTimeDate()+*/'[BLE_SO]port_not avalilable');
      //if(logger)  
        //logger.log(GetTimeDate()+'[BLE_SO]port_not avalilable');
      forceDisconnect();
	
      return 0;    //=> true
    }
  });
}

function getConnection(connName){
  Gradar_Client = net.connect({port: 5999, host:'localhost'}, function() {
    console.log(/*GetTimeDate()+*/'[BLE_SO]connected to server');
    console.log(/*GetTimeDate()+*/'[BLE_SO]local = %s:%s', this.localAddress, this.localPort);
    console.log(/*GetTimeDate()+*/'[BLE_SO]remote = %s:%s', this.remoteAddress, this.remotePort);
    //console.log('[BLE_SO]connected peripheral:', this.advertisement.localName);

    //if(logger)  
    //{
      //logger.log(GetTimeDate()+'[BLE_SO]connected to server');
      //logger.log(GetTimeDate()+'[BLE_SO]local = %s:%s', this.localAddress, this.localPort);
      //logger.log(GetTimeDate()+'[BLE_SO]remote = %s:%s', this.remoteAddress, this.remotePort);
    //}

    // timeout   
    Gradar_Client.setTimeout(60000);
    
	// 2022.04.04, PMK, 
	var fs = require('fs');
	var BLE_MODE=2;  //0(discon), 1(Central),2(peripheral)  
	fs.writeFileSync('/home/pi/test/ble_mode.log',BLE_MODE); 
	
    //this.setEncoding('utf8');

    });


    Gradar_Client.on('data', function(data) {
      //console.log(GetTimeDate()+'[BLE_SO]Rec:' + data.toString('hex'));
      // pmk
      if( data != '' && _updateValueCallback != null )
      {
          console.log('[BLE_SO]Send2BLE: ' + data );
          //if(logger)  
            //logger.log(GetTimeDate()+">: " + data);

          _updateValueCallback(data);
          data = '';
      }
    });

    Gradar_Client.on('end', function() {
       console.log(/*GetTimeDate()+*/'[BLE_SO]disconnected');
       //if(logger)  
       // logger.log(GetTimeDate()+'[BLE_SO]disconnected'); 
       forceDisconnect();
    });

    Gradar_Client.on('error', function(err) {
       console.log(GetTimeDate()+'[BLE_SO]err : ' + err);
       //if(logger)  
       // logger.log(GetTimeDate()+'[BLE_SO]err : ' + err); 
       forceDisconnect();
    });

    Gradar_Client.on('timeout', function() {
        console.log(/*GetTimeDate()+*/'[BLE_SO]connection timeout');	
        //if(logger)  
         // logger.log(GetTimeDate()+'[BLE_SO]connection timeout');	
        forceDisconnect();
    });

    Gradar_Client.on('close', function() {
        console.log(/*GetTimeDate()+*/'[BLE_SO]connection Closed');	
        //if(logger)  
          //logger.log(GetTimeDate()+'[BLE_SO]connection Closed');	
        forceDisconnect();
    });

  return Gradar_Client;
}

function writeData(socket, data)
{
	if(port_avalilable==1)
	{	
		var success = !socket.write(data);
	}
	
  /*
  if (!success){
    (function(socket, data){
      socket.once('drain', function(){
        writeData(socket, data);
      });
    })(socket, data);
  }  
  */
}


var ReadCharacteristic = function() {
  ReadCharacteristic.super_.call(this, {
    //uuid: '000100019FAB43C8923140F6E305F961',
    uuid: 'dec7cf02c15943c49fee0efde1a0f54b',
    properties: ['read'],
    value: new Buffer('GRadar'),
    descriptors: [
      new BlenoDescriptor({
        uuid: '2901',
        value: 'user description'
      })
    ]
  });
};
util.inherits(ReadCharacteristic, BlenoCharacteristic);

var WriteCharacteristic = function() {
  WriteCharacteristic.super_.call(this, {
    //uuid: '000100019FAB43C8923140F6E305F962',
    uuid: 'dec7cf03c15943c49fee0efde1a0f54b',
    properties: ['write','writeWithoutResponse']
  });
};

util.inherits(WriteCharacteristic, BlenoCharacteristic);

WriteCharacteristic.prototype.onWriteRequest = function(data, offset, withoutResponse, callback) {
 console.log(/*GetTimeDate()+*/'[BLE]WriteCharacteristic write request: ' + data.toString('hex') + ' ' + offset + ' ' + withoutResponse);
 //if(logger)  
  //logger.log(GetTimeDate()+"<: " + data);

	// 2022.10.25 PMK, To get the Put and Watch Name 
   str_hb = data.toString('utf8');
   str_hb1="";
   var str_i=0;
   for(let i=0;i<38;i++)
    if(str_hb[i]==',')
     str_i=i;
   var end_i=str_i+1;
   for(let i=0;i<38;i++)
    if(str_hb[i]==',' || str_hb[i]=='%')
     end_i=i;
   console.log(str_i);
   console.log(end_i);
   for(let i=str_i+1;i<end_i;i++)
    str_hb1 += str_hb[i];
  console.log(str_hb1);
	var fs = require('fs');
	fs.writeFileSync('/home/pi/test/put_name.log',str_hb1); 
	
  writeData(Gradar_BLE, data);

  callback(this.RESULT_SUCCESS);
};

var NotifyCharacteristic = function() {
  NotifyCharacteristic.super_.call(this, {
    //uuid: '000100019FAB43C8923140F6E305F963',
    uuid: 'dec7cf04c15943c49fee0efde1a0f54b',
    properties: ['notify']
  });
};

util.inherits(NotifyCharacteristic, BlenoCharacteristic);

NotifyCharacteristic.prototype.onSubscribe = function(maxValueSize, updateValueCallback) {
  console.log(/*GetTimeDate()+*/'[BLE]NotifyCharacteristic subscribe');
  //if(logger)  
    //logger.log(GetTimeDate()+'[BLE]NotifyCharacteristic subscribe');

  _updateValueCallback = updateValueCallback;
};


NotifyCharacteristic.prototype.onUnsubscribe = function() {
  console.log(/*GetTimeDate()+*/'[BLE]NotifyCharacteristic unsubscribe');
  //if(logger)  
    //logger.log(GetTimeDate()+'[BLE]NotifyCharacteristic unsubscribe'); 
};

NotifyCharacteristic.prototype.onNotify = function() {
  console.log(/*GetTimeDate()+*/'[BLE]NotifyCharacteristic on notify');
  //if(logger)  
    //logger.log(GetTimeDate()+'[BLE]NotifyCharacteristic on notify'); 
};


// INDICATE 
var IndicateOnlyCharacteristic = function() {
  IndicateOnlyCharacteristic.super_.call(this, {
    //uuid: '000100019FAB43C8923140F6E305F964',
    uuid: 'dec7cf05c15943c49fee0efde1a0f54b',
    properties: ['indicate']
  });
};

util.inherits(IndicateOnlyCharacteristic, BlenoCharacteristic);

IndicateOnlyCharacteristic.prototype.onSubscribe = function(maxValueSize, updateValueCallback) {
  console.log(/*GetTimeDate()+*/'[BLE]IndicateOnlyCharacteristic subscribe');
  //if(logger)  
    //logger.log(GetTimeDate()+'[BLE]IndicateOnlyCharacteristic subscribe');

  _updateValueCallback = updateValueCallback;
};

IndicateOnlyCharacteristic.prototype.onUnsubscribe = function() {
  console.log(/*GetTimeDate()+*/'[BLE]IndicateOnlyCharacteristic unsubscribe');
  //if(logger)  
    //logger.log(GetTimeDate()+'[BLE]IndicateOnlyCharacteristic unsubscribe');
};

IndicateOnlyCharacteristic.prototype.onNotify = function() {
  console.log(/*GetTimeDate()+*/'[BLE]IndicateOnlyCharacteristic on notify');
  //if(logger)  
    //logger.log(GetTimeDate()+'[BLE]IndicateOnlyCharacteristic on notify'); 
};

function GolfZoneService() {
  GolfZoneService.super_.call(this, {
    //uuid: '000100019FAB43C8923140F6E305F960',
    uuid: 'dec7cf01c15943c49fee0efde1a0f54b',
    characteristics: [
      new ReadCharacteristic(),
      new WriteCharacteristic(),
      new NotifyCharacteristic(),
      new IndicateOnlyCharacteristic()
    ]
  });
}

util.inherits(GolfZoneService, BlenoPrimaryService);

bleno.on('stateChange', function(state) {
  console.log(/*GetTimeDate()+*/'[BLE]on -> stateChange: ' + state + ', address = ' + bleno.address);
  //if(logger)  
    //logger.log(GetTimeDate()+'[BLE]on -> stateChange: ' + state + ', address = ' + bleno.address);

  var bleno_str=util.format("%s",bleno.address);
  var mac_addr = bleno_str.replace(/:/g,"");
  bleno_str="WAVE_"+mac_addr.substring(4,12);
  //bleno_str="DT_BLE_"+bleno_str.substring(9,19);
  //console.log("DT_BLE_"+bleno_str.substring(6,19));

  if (state == 'poweredOn') {
    //bleno.startAdvertising('GOLFZON GRadar', ['000100019FAB43C8923140F6E305F960']);
    //bleno.startAdvertising(bleno_str, ['000100019FAB43C8923140F6E305F960']);
    bleno.startAdvertising(bleno_str, ['dec7cf01c15943c49fee0efde1a0f54b']);
  } else {
    bleno.stopAdvertising();
  }
});

bleno.on('accept', function(clientAddress) {
    //output = fs.createWriteStream('/home/dbgftp/BT_Log/ble_'+GetTimeDate_file()+'.txt',{flags:'w+'});
    //logger = new Console(output);

    console.log(/*GetTimeDate()+*/'[BLE]on -> accept, client: ' + clientAddress);
    //if(logger)  
      //logger.log(GetTimeDate()+'[BLE]on -> accept, client: ' + clientAddress);

    bleno.updateRssi();

    isPortAvailbleFunc(port);
    
    //console.log('[BLE]port_avalilable: ' + port_avalilable);

    BLEConnected = true;
	  
	// 2022.03.25 PMK, 
    var mac = clientAddress;
    var BLE_MAC = mac[12]+mac[13]+mac[15]+mac[16];  
    console.log('[BLE_C]BLE_MAC',BLE_MAC);    
    var fs = require('fs');
    fs.writeFileSync('/home/pi/test/ble_mac.log',BLE_MAC); 
		  
    //setTimeout(function(){      
    //    forceDisconnect();
    //}, 5000);

});

bleno.on('disconnect', function(clientAddress) {
  console.log(/*GetTimeDate()+*/'[BLE]on -> disconnect, client: ' + clientAddress);
  //if(logger)  
    //logger.log(GetTimeDate()+'[BLE]on -> disconnect, client: ' + clientAddress); 
  
  BLEConnected = false;

  if(Gradar_Client)
    Gradar_Client.end();

  if(logger)  
    delete logger;

  if(output)
    output.end(function(){console.log('[BLE]File_End')});
	
	// 2022.04.04, PMK, 
	var fs = require('fs');
	var BLE_MODE=0; // 0(discon), 1(peripheral),2(Central) 
	fs.writeFileSync('/home/pi/test/ble_mode.log',BLE_MODE); 
	
	// 2022.10.25 PMK, To get the Put and Watch Name 
	var fs1 = require('fs');
	var mac=0;
	fs1.writeFileSync('/home/pi/test/put_name.log',mac); 
			
  });

bleno.on('rssiUpdate', function(rssi) {
  console.log(/*GetTimeDate()+*/'[BLE]on -> rssiUpdate: ' + rssi);
  //if(logger)  
    //logger.log(GetTimeDate()+'[BLE]on -> rssiUpdate: ' + rssi); 
});
//////////////////////////////////////

bleno.on('mtuChange', function(mtu) {
  console.log(/*GetTimeDate()+*/'[BLE]on -> mtuChange: ' + mtu);
  //if(logger)  
    //logger.log(GetTimeDate()+'[BLE]on -> mtuChange: ' + mtu);  
});

bleno.on('advertisingStart', function(error) {
  console.log(/*GetTimeDate()+*/'[BLE]on -> advertisingStart: ' + (error ? 'error ' + error : 'success'));
  //if(logger)  
    //logger.log(GetTimeDate()+'[BLE]on -> advertisingStart: ' + (error ? 'error ' + error : 'success'));

  if (!error) {
    bleno.setServices([
      new GolfZoneService()
    ]);    
  }
});

bleno.on('advertisingStop', function() {
  console.log(/*GetTimeDate()+*/'[BLE]on -> advertisingStop');
  //if(logger)  
    //logger.log(GetTimeDate()+'[BLE]on -> advertisingStop');
});

bleno.on('servicesSet', function(error) {
  console.log(/*GetTimeDate()+*/'[BLE]on -> servicesSet: ' + (error ? 'error ' + error : 'success'));
  //if(logger)  
    //logger.log(GetTimeDate()+'[BLE]on -> servicesSet: ' + (error ? 'error ' + error : 'success'));
});


function forceDisconnect(){
    console.log(/*GetTimeDate()+*/'[BLE]on -> forceDisconnect');
    //if(logger)  
      //logger.log(GetTimeDate()+'[BLE]on -> forceDisconnect'); 

    if(BLEConnected){
       bleno.disconnect();
       BLEConnected = false;
    }
 }
