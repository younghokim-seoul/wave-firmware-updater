// 2021.11.09 PMK, NanoPi Central  
var noble = require('../..');
var isPortReachable = require('is-port-reachable');
var net = require('net');
var fs = require('fs'); 
require('date-utils');
const path = require('path');

// pmk
//var PuttServiceUuid = 'dec7cf01c15943c49fee0efde1a0f54b';
//var PuttReadCharacteristicUuid = 'dec7cf02c15943c49fee0efde1a0f54b';
//var PuttWriteCharacteristicUuid = 'dec7cf03c15943c49fee0efde1a0f54b';
//var PuttNotiCharacteristicUuid = 'dec7cf04c15943c49fee0efde1a0f54b';

// IR PUT 
var PuttServiceUuid = 'dec70001c15943c49fee0efde1a0f54b';
var PuttReadCharacteristicUuid = 'dec70004c15943c49fee0efde1a0f54b';
var PuttWriteCharacteristicUuid = 'dec70003c15943c49fee0efde1a0f54b';
var PuttNotiCharacteristicUuid = 'dec70002c15943c49fee0efde1a0f54b';

var BLEConnected = false;
var Gradar_BLE;
var port=5999;
var port_avalilable=0;
var Gradar_Client;
var Putt_Mac;


const logDir = '/home/dbgftp/BT_Log';
const logFilePattern = /\.log$/i;
const maxFileSize = 3 * 1024;


function deleteSmallLogFiles() {
  fs.readdir(logDir, (err, files) => {
    if (err) {
      console.error('Error reading log directory:', err);
      return;
    }

    files.forEach((file) => {
      if (logFilePattern.test(file)) {
        const filePath = path.join(logDir, file);
        const stats = fs.statSync(filePath);
        if (stats.size <= maxFileSize) {
          fs.unlinkSync(filePath);
          console.log('Deleted log file:', filePath);
        }
      }
    });
  });
}

deleteSmallLogFiles();

// log4js 
const log4js = require('log4js');
require('date-utils');
log4js.configure({
  appenders: { 
	out: { type: 'console' }, 
	//task: { type: 'dateFile', filename: 'task_', pattern: 'yyyyMMddhhmmss.log', alwaysIncludePattern: true } 
	task:{
	 type: 'multiFile', base: '/home/dbgftp/BT_Log/', property: 'userID',
	 extension: '.log', maxLogSize: 3000000, backups: 10, compress: true
 	} // 5242880(5MB) 
 },
  categories: { 
  default: { appenders: ['out','task'], level: 'info' },    // both log file and console 
  //default: { appenders: ['task'], level: 'info' },      // only log file 
	task: { appenders: ['task'], level: 'info'} 
  }
});
const logger4 = log4js.getLogger('console');
console.log = logger4.info.bind(logger4);
logger4.addContext('userID', /*new Date().toFormat('YYYYMMDD_HH24MISS')*/ 'BLE_Put_'+GetTimeDate_1());
logger4.info('log4js start');

fs.exists("/home/pi/test/ble_mode.log", function(exists){
		if(exists){	
			fs.unlinkSync("/home/pi/test/ble_mode.log");	
		}
}); 

// date 
function GetTimeDate(){
  var x = new Date();
  //var myVar1 = x.getMonth()+1;  
  //var myVar2 = x.getDate();
  var myVar3 = x.getHours();
  var myVar4 = x.getMinutes();
  var myVar5 = x.getSeconds();
  //var GetDate = '[' + myVar1+':'+myVar2+':'+myVar3+':'+myVar4+':'+myVar5 + ']';
  var GetDate = '[' + myVar3+':'+myVar4+':'+myVar5+']';
  return GetDate;
  //return x.toFormat('YYYYMMDD_HH24MISS');
}

// date 
function GetTimeDate_1(){
  var x = new Date();
  var myVar1 = x.getMonth()+1;  
  var myVar2 = x.getDate();
  var myVar3 = x.getHours();
  var myVar4 = x.getMinutes();
  var myVar5 = x.getSeconds();
  var GetDate = '[' + myVar1+':'+myVar2+':'+myVar3+':'+myVar4+':'+myVar5 + ']';
  //var GetDate = '[' + myVar3+':'+myVar4+':'+myVar5+']';
  //return GetDate;
  return x.toFormat('YYYYMMDD_HH24MISS');
}

function forceDisconnect(){
    console.log(/*GetTimeDate()+*/'[BLE_C]on -> forceDisconnect');
    if(BLEConnected){
       noble.disconnect();
       BLEConnected = false;
	   
	   	 // 2022.04.04, PMK, 
		var fs = require('fs');
		var BLE_MODE=0; // 0(discon), 1(peripheral),2(Central) 
		fs.writeFileSync('/home/pi/test/ble_mode.log',BLE_MODE); 
		
		// 2022.10.25 PMK, To get the Put and Watch Name 
		var fs1 = require('fs');
		var mac=0;
		fs1.writeFileSync('/home/pi/test/put_name.log',mac); 
			
    }
 }

function isPortAvailbleFunc(port){
    isPortReachable(port).then(reachable => {
    console.log(/*GetTimeDate()+*/'[BLE_C]isPortReachable: '+port);
    if(reachable==true)
    {
      port_avalilable=1;
      Gradar_BLE = getConnection("BLE");
      console.log(/*GetTimeDate()+*/'[BLE_C]port_avalilable');
	  
	
      return 1;
    }
    else
    {
      port_avalilable=0;
      console.log(/*GetTimeDate()+*/'[BLE_C]port_not avalilable');
      forceDisconnect();
		
      return 0;    //=> true
    }
  });
}

function getConnection(connName){
  Gradar_Client = net.connect({port: 5999, host:'localhost'}, function() {
    console.log(/*GetTimeDate()+*/'[BLE_C]connected to server');
    console.log(/*GetTimeDate()+*/'[BLE_C]local = %s:%s', this.localAddress, this.localPort);
    console.log(/*GetTimeDate()+*/'[BLE_C]remote = %s:%s', this.remoteAddress, this.remotePort);
    
    // timeout   
    Gradar_Client.setTimeout(60000);
    });

	// 2022.04.04, PMK, 
	var fs = require('fs');
	var BLE_MODE=1; // 0(discon), 1(Central),2(peripheral)  
	fs.writeFileSync('/home/pi/test/ble_mode.log',BLE_MODE); 
		
		
    Gradar_Client.on('data', function(data) {
      // pmk
      if( data != '')
      {
          console.log(/*GetTimeDate()+*/'[BLE_C]Sock2BLE: ' + data );
          PuttWriteCharacteristic.write(data);
          data = '';
      }
    });

    Gradar_Client.on('end', function() {
       console.log(/*GetTimeDate()+*/'[BLE_C]disconnected');
       forceDisconnect();
    });
    Gradar_Client.on('error', function(err) {
       console.log(/*GetTimeDate()+*/'[BLE_C]err : ' + err);
       forceDisconnect();
    });
    Gradar_Client.on('timeout', function() {
        console.log(/*GetTimeDate()+*/'[BLE_C]connection timeout');	
        forceDisconnect();
    });
    Gradar_Client.on('close', function() {
        console.log(/*GetTimeDate()+*/'[BLE_C]connection Closed');	
        forceDisconnect();
    });

  return Gradar_Client;
}

// send data to socket 
function writeData(socket, data)
{
  if(port_avalilable==1)
  {
    console.log(/*GetTimeDate()+*/'[BLE_C]BLEtoSocket');
    var success = !socket.write(data);
  }
}

noble.on('stateChange', function(state) {
  if (state === 'poweredOn') {
    if(process.argv[2])
    {
      Putt_Mac=process.argv[2];
      console.log('PAR :' , process.argv[2]); 
    }
	

   console.log(/*GetTimeDate()+*/'[BLE_C]1.Scanning...');
    //noble.startScanning([PuttServiceUuid], false);
    noble.startScanning([PuttServiceUuid], true);
  }
  else {
    console.log(/*GetTimeDate()+*/'[BLE_C]Scan Error(cause poweron)');
    noble.stopScanning();
  }
})


noble.on('disconnect', function(data) {
   console.log(/*GetTimeDate()+*/'[BLE_C]Disconnect...'+data);
  
  BLEConnected = false;

  if(Gradar_Client)
    Gradar_Client.end();
    
})
  
  
  
var PuttService = null;
var PuttReadCharacteristic = null;
var PuttWriteCharacteristic = null; 
var PuttNotiCharacteristic = null; 

noble.on('discover', function(peripheral) {
  // we found a peripheral, stop scanning
  noble.stopScanning();

	// 2022.06.22 PMK, 
	var SCAN_BUT=0;
	var PUT_AUTO=0;
	var fs_r = require('fs');
	PUT_AUTO = fs_r.readFileSync('/home/pi/test/put_auto.log',{encoding:'utf8',flag:'r'}); 
	console.log(GetTimeDate()+'[BLE_C]2.PUT_AUTO:', PUT_AUTO);
		
  console.log(GetTimeDate()+'[BLE_C]2.Found peripheral:', peripheral.advertisement);
  
  var par_name1 = "DT_BLE_1d:";
  var par_name2, par_name3, par_name4, par_name5;    
  console.log('[BLE_C]par_name1',par_name1);
  if(Putt_Mac)
  {
    par_name2 = Putt_Mac;  
    par_name2 = par_name2.toUpperCase();    // �빮��     
    par_name3 = par_name2.toLowerCase();    // �ҹ��� 
    par_name4 = par_name1 + par_name2[0] + par_name2[1] + ":" + par_name2[2] + par_name2[3]; 
    par_name5 = par_name1 + par_name3[0] + par_name3[1] + ":" + par_name3[2] + par_name3[3]; 
    console.log('[BLE_C]par_name4,5',par_name4,par_name5);
  }
   
  // 2022.06.20 PMK, AD DATA  
  var serviceData = peripheral.advertisement.serviceData;
  var ManufactureData = peripheral.advertisement.manufacturerData;  
  //serviceData = 'G-Putt';	// test 
  console.log('[BLE_C]:AD Service Data = ' + serviceData );
  console.log('[BLE_C]:AD manufacturerData Data  = ' + ManufactureData );
  //console.log('[BLE_C]:AD manufacturerData Data  = ' + ManufactureData[0] );  
  //console.log('[BLE_C]:AD manufacturerData Data  = ' + ManufactureData[1] );    
  //console.log('[BLE_C]:AD manufacturerData Data  = ' + ManufactureData[2] ); 
  
  if (PUT_AUTO==1) 
  {
      console.log('[BLE_C]:PUT_AUTO      = ' + PUT_AUTO);
	  SCAN_BUT=1;
  }
	
  var name = peripheral.advertisement.localName;
  console.log(`[BLE_C]2.Found peripheral name and id : ${name} , ${peripheral.id}`);
  var name1,name2,name3;
  if(name)
  {
    // G-Putt_5240 (11�ڸ� �⺻ �Է�)
    name1 = name[0]+name[1]+name[2]+name[3]+name[4]+name[5]+name[6]+name[7]+name[8]+name[9]+name[10];
    name2 = name[0]+name[1]+name[2]+name[3]+name[4]+name[5]+name[6]; 
    // gradar (10�ڸ� �⺻ �Է�) 
    name3 = name[0]+name[1]+name[2]+name[3]+name[4]+name[5]+name[6]+name[7]+name[8]+name[9];
    console.log('[BLE_C]par_name1',name1);
    console.log('[BLE_C]par_name2',name2);
    console.log('[BLE_C]par_name3',name3);    
  }
      
  var par_name6 = "G-Putt_";
  var par_name7, par_name8, par_name9, par_name10;    
  console.log('[BLE_C]par_name6',par_name6);
  if(Putt_Mac)
  {
    par_name7 = Putt_Mac;  
    par_name7 = par_name7.toUpperCase();    // �빮��     
    par_name8 = par_name7.toLowerCase();    // �ҹ��� 
    par_name9 = name1 + par_name7[0] + par_name7[1] + par_name7[2] + par_name7[3]; 
    par_name10 = name1 + par_name8[0] + par_name8[1] + par_name8[2] + par_name8[3]; 
    console.log('[BLE_C]par_name9,10',par_name9,par_name10);
  }
  
  // check device name  
  var Connect_Put=0;
  if(SCAN_BUT==0)
  {
	if((name == par_name4 || name == par_name5 || name == par_name9 || name == par_name10) &&  Putt_Mac)
		Connect_Put=1;
	if((name2 == par_name6 || name3 == par_name1) && (!Putt_Mac))
		Connect_Put=2;
  }
  else // SCAN_BUT is 1 
  {
	if(/*(name2 == par_name6)&&*/ (ManufactureData=='G-Putt'))
		Connect_Put=3;
  }
  console.log('[BLE_C]Connect_Put is ',Connect_Put);
  
  
  //if(name == "DT_BLE_1d:d2:04")
  // �켱���� PUT_MAC ������ par_name4,par_name5,par_name9,par_name10 ������ ���� par_name1,par_name6
  if(/* ((name == par_name4 || name == par_name5 || name == par_name9 || name == par_name10) &&  Putt_Mac)
      || ((name2 == par_name6 || name3 == par_name1) && (!Putt_Mac))
		|| ((name2 == par_name6)&& (SCAN_BUT==1))*/
		Connect_Put > 0
    )
  {
       if(name == par_name4)
        console.log('[BLE_C]par_name4_Found',par_name4);    
       if(name == par_name5)
        console.log('[BLE_C]par_name5_Found',par_name5);     
       if(name == par_name9)
        console.log('[BLE_C]par_name9_Found',par_name9);   
      if(name == par_name10)
        console.log('[BLE_C]par_name10_Found',par_name10);   
       if(name == par_name6)
        console.log('[BLE_C]par_name6_Found',par_name6);       
       if(name == par_name1)
        console.log('[BLE_C]par_name1_Found',par_name1);       
		
  
  peripheral.connect(function(err) {

      console.log('[BLE_C]3.connected peripheral:', peripheral.advertisement.localName);
 
    peripheral.discoverServices([PuttServiceUuid], function(err, services) {
      services.forEach(function(service) {
        
          console.log('[BLE_C]3.Connect and Found service:', service.uuid);
          
          // 2022.03.25 PMK, 
          var mac = peripheral.advertisement.localName;
          var PUT_MAC = mac[11]+mac[12]+mac[13]+mac[14];  
          console.log('[BLE_C]PUT_MAC',PUT_MAC);    
          var fs = require('fs');
          fs.writeFileSync('/home/pi/test/put_mac.log',PUT_MAC); 

		// 2022.10.25 PMK, To get the Put and Watch Name 
		var fs = require('fs');
		fs.writeFileSync('/home/pi/test/put_name.log',mac); 
	
        isPortAvailbleFunc(port);

        BLEConnected = true;
 
        service.discoverCharacteristics([], function(err, characteristics) {

          characteristics.forEach(function(characteristic) {
           
            //console.log('[BLE_C]found characteristic:', characteristic.uuid);

	    // pmk 
            if (PuttReadCharacteristicUuid == characteristic.uuid) {
              PuttReadCharacteristic = characteristic;
               console.log('[BLE_C]found Read characteristic:', characteristic.uuid);
            }

            if(PuttWriteCharacteristicUuid == characteristic.uuid) {
              PuttWriteCharacteristic = characteristic;
              console.log('[BLE_C]found Write characteristic:', characteristic.uuid);
            }

	    if (PuttNotiCharacteristicUuid == characteristic.uuid) {
              PuttNotiCharacteristic = characteristic;
              console.log('[BLE_C]found Noti characteristic:', characteristic.uuid);
            }	
          })


          if (PuttWriteCharacteristic)
          {
             console.log('[BLE_C]Write characteristics');	      
            //const message = new Buffer('$$PUT 1%                              ##');
            //PuttWriteCharacteristic.write(message);
            //console.log('[BLE_C]Send_PUT_1');  
         }

          if (PuttReadCharacteristic) 
          {
             console.log('[BLE_C]Read characteristics');   
            //const message = new Buffer('$$PUT 1%                              ##');
            //writeData(Gradar_BLE, message);
            //PuttReadCharacteristic.read(function(error,data)
            //{
            //  console.log('[BLE_C]Read Data : ' + data);
            //});
          }

	 if(PuttNotiCharacteristic) 
      {
          console.log('[BLE_C]PuttNotiCharacteristic!');
          PuttNotiCharacteristic.on('read', function(data, isNotification)
          {
               console.log('[BLE_C]PuttNotiCharacteristic[read]!');
             var str_hb;
             var str_hb1;
             if(data != '')
             { 
                console.log('[BLE_C]Noti_Rec_Data: ' + data);
               str_hb = data.toString('utf8');
               //console.log(str_hb[2] + str_hb[3]);
               str_hb1 =  str_hb[2] + str_hb[3];
               //if(str_hb1 != 'HB')
                writeData(Gradar_BLE, data);
             }            
          });          			

           PuttNotiCharacteristic.notify(true, function(err) 
           {
            const data = new Buffer('$$PUT 3%                              ##');
 	    console.log('[BLE_C]PuttNotiCharacteristic[notify]!');
            PuttNotiCharacteristic.write(data, false, function(err) 
            {
              if(err) 
                 console.log('[BLE_C]noti error');
              else 
              {
                console.log('[BLE_C]noti ok');
                const message = new Buffer('$$PUT 1%                              ##');
                PuttWriteCharacteristic.write(message);
              }
            }); 
          }); 
          
          
        }   //  if(PuttNotiCharacteristic) 
   
          //create an interval to send data to the service
          let count = 0;
          if(BLEConnected)    // HB���� TEST���ؼ��� �̰� ���� 
          {
            const message = new Buffer('$$PUT 1%                              ##');
            PuttWriteCharacteristic.write(message);
            console.log('[BLE_C]Send_PUT_1');  
            
            setInterval(() => {
              count++;
                if(BLEConnected)  // HB���� TEST���ؼ��� �̰� ���� 
                {
                  const message = new Buffer('$$HB%                                 ##');
                  console.log('[BLE_C]Send to HB');
                  PuttWriteCharacteristic.write(message);
                }
              }, 13000);
            }   //  if(BLEConnected)
          
        })
      })
    })
  })
  } // if(name == par_name4 || name == par_name5)
  else
  {
        console.log('[BLE_C]Putter is not Found ',name, ',', par_name2,);
  }
})



 


