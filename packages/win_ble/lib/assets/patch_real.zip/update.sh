#!/bin/bash
# Golfzon Radar Mini Patch 
# 2022.02.14 PMK :  PATCH  , ADD FILE , DELETE FILE, ONTIME RUN ETC 

echo "update.sh[START]" $(date +%T)
# define folder  
TEST=/home/pi/test
BT=/home/pi/bt
CAM=/home/pi/cam 
PI=/home/pi
UPDATE=/home/upgrade/GRadar_DLL
WWW=/home/pi/cam/www
BTCEN=/home/pi/node_modules/noble/examples/pizza/
BTPER=/home/pi/node_modules/bleno/
ROOT=/

# 압축해제 
if [ -e $UPDATE/patch.zip ]; then
sudo unzip -P "GOLFZONWAVE" $UPDATE/patch.zip -d  $UPDATE/
#sudo rm -rf $UPDATE/patch.zip
#sudo zip --password "GOLFZONWAVE" patch.zip *
sleep 1 
sudo chmod 777 * 
fi 
if [ -e $UPDATE/PATCH.ZIP ]; then
sudo unzip -P "GOLFZONWAVE" $UPDATE/PATCH.ZIP -d  $UPDATE/
sleep 1 
sudo chmod 777 * 
fi 
if [ -e $UPDATE/PATCH.zip ]; then
sudo unzip -P "GOLFZONWAVE" $UPDATE/PATCH.zip -d  $UPDATE/
sleep 1 
sudo chmod 777 * 
fi 
if [ -e $UPDATE/patch.ZIP ]; then
sudo unzip -P "GOLFZONWAVE" $UPDATE/patch.ZIP -d  $UPDATE/
sleep 1 
sudo chmod 777 * 
fi


# define file name   
# test folder 14 (1~14)
FILE1=rst_digitalbd.sh
FILE2=e6_ver.sh
FILE3=rm_jpg.sh
FILE4=rm_log.sh
FILE5=rm_rbf.sh
FILE6=node_pmk_put.sh
FILE7=set_phaseWcal.sh
FILE8=check_rpi.sh
FILE9=reset_factory.sh
FILE10=check_E6.sh
FILE11=fw_down.sh
FILE12=check_DLL.sh
FILE13=check_fw_finish.sh
FILE14=DT_up.sh
FILE15=date_set.sh
FILE16=check_DFU.sh
FILE17=set_posx_limit.sh
FILE18=phase_jig.sh
FILE19=launch_jig
FILE20=phase_config.sh
FILE21=kill_phase_jig.sh
FILE22=jig_ver.sh
FILE23=check_patch.sh


# cam folder 10 (30~40)
FILE30=cam_run_1.sh
FILE31=cam_cal.out

# bt folder 10 (41~44)
FILE41=bt_check.sh


# PI folder 10 (45~50)
FILE45=launcher.sh

# Delete file 10(51~60)
#FILE51=/home/cam/swing.mp4


# www folder 10 (61~70)
FILE61=ERR_CODE.html

# bluetooth node folder for Central (71~)
FILE71=ble_cen.js
FILE72=central_pmk.js

# bluetooth node folder for Peripheral (75~)
FILE75=ble_per.js
FILE76=gradar_ble.js

# ROOT 
FILE80=GRadar_Info.xml

# run onetime 
FILE90=onetime.sh
	
#copy file 
# test folder
if [ -e $UPDATE/$FILE1 ]; then
DIF=0
DIF=`diff -c $UPDATE/$FILE1 $TEST/$FILE1`
if [ -z "$DIF" ] && [ -e $TEST/$FILE1 ] ; then
 sudo echo "same"
else
sudo cp $UPDATE/$FILE1 $TEST/$FILE1
sudo chmod 777 $TEST/*
sudo rm $UPDATE/$FILE1
fi 
fi 

if [ -e $UPDATE/$FILE2 ]; then
DIF=0
DIF=`diff -c $UPDATE/$FILE2 $TEST/$FILE2`
if [ -z "$DIF" ] && [ -e $TEST/$FILE2 ] ; then
 sudo echo "same"
else
sudo cp $UPDATE/$FILE2 $TEST/$FILE2
sudo chmod 777 $TEST/*
sudo rm $UPDATE/$FILE2
fi 
fi 

if [ -e $UPDATE/$FILE3 ]; then
DIF=0
DIF=`diff -c $UPDATE/$FILE3 $TEST/$FILE3`
if [ -z "$DIF" ] && [ -e $TEST/$FILE3 ] ; then
 sudo echo "same"
else
sudo cp $UPDATE/$FILE3 $TEST/$FILE3
sudo chmod 777 $TEST/*
sudo rm $UPDATE/$FILE3
fi 
fi 

if [ -e $UPDATE/$FILE4 ]; then
DIF=0
DIF=`diff -c $UPDATE/$FILE4 $TEST/$FILE4`
if [ -z "$DIF" ] && [ -e $TEST/$FILE4 ] ; then
 sudo echo "same"
else
sudo cp $UPDATE/$FILE4 $TEST/$FILE4
sudo chmod 777 $TEST/*
sudo rm $UPDATE/$FILE4
fi 
fi 

if [ -e $UPDATE/$FILE5 ]; then
DIF=0
DIF=`diff -c $UPDATE/$FILE5 $TEST/$FILE5`
if [ -z "$DIF" ] && [ -e $TEST/$FILE5 ] ; then
 sudo echo "same"
else
sudo cp $UPDATE/$FILE5 $TEST/$FILE5
sudo chmod 777 $TEST/*
sudo rm $UPDATE/$FILE5
fi 
fi 

if [ -e $UPDATE/$FILE6 ]; then
DIF=0
DIF=`diff -c $UPDATE/$FILE6 $TEST/$FILE6`
if [ -z "$DIF" ] && [ -e $TEST/$FILE6 ] ; then
 sudo echo "same"
else
sudo cp $UPDATE/$FILE6 $TEST/$FILE6
sudo chmod 777 $TEST/*
sudo rm $UPDATE/$FILE6
fi 
fi 

if [ -e $UPDATE/$FILE7 ]; then
DIF=0
DIF=`diff -c $UPDATE/$FILE7 $TEST/$FILE7`
if [ -z "$DIF" ] && [ -e $TEST/$FILE7 ] ; then
 sudo echo "same"
else
sudo cp $UPDATE/$FILE7 $TEST/$FILE7
sudo chmod 777 $TEST/*
sudo rm $UPDATE/$FILE7
fi 
fi 

if [ -e $UPDATE/$FILE8 ]; then
DIF=0
DIF=`diff -c $UPDATE/$FILE8 $TEST/$FILE8`
if [ -z "$DIF" ] && [ -e $TEST/$FILE8 ] ; then
 sudo echo "same"
else
sudo cp $UPDATE/$FILE8 $TEST/$FILE8
sudo chmod 777 $TEST/*
sudo rm $UPDATE/$FILE8
fi 
fi 

if [ -e $UPDATE/$FILE9 ]; then
DIF=0
DIF=`diff -c $UPDATE/$FILE9 $TEST/$FILE9`
if [ -z "$DIF" ] && [ -e $TEST/$FILE9 ] ; then
 sudo echo "same"
else
sudo cp $UPDATE/$FILE9 $TEST/$FILE9
sudo chmod 777 $TEST/*
sudo rm $UPDATE/$FILE9
fi 
fi 

if [ -e $UPDATE/$FILE10 ]; then
DIF=0
DIF=`diff -c $UPDATE/$FILE10 $TEST/$FILE10`
if [ -z "$DIF" ] && [ -e $TEST/$FILE10 ] ; then
 sudo echo "same"
else
sudo cp $UPDATE/$FILE10 $TEST/$FILE10
sudo chmod 777 $TEST/*
sudo rm $UPDATE/$FILE10
fi 
fi 

if [ -e $UPDATE/$FILE11 ]; then
DIF=0
DIF=`diff -c $UPDATE/$FILE11 $TEST/$FILE11`
if [ -z "$DIF" ] && [ -e $TEST/$FILE11 ] ; then
 sudo echo "same"
else
sudo cp $UPDATE/$FILE11 $TEST/$FILE11
sudo chmod 777 $TEST/*
sudo rm $UPDATE/$FILE11
fi 
fi 

if [ -e $UPDATE/$FILE12 ]; then
DIF=0
DIF=`diff -c $UPDATE/$FILE12 $TEST/$FILE12`
if [ -z "$DIF" ] && [ -e $TEST/$FILE12 ] ; then
 sudo echo "same"
else
sudo cp $UPDATE/$FILE12 $TEST/$FILE12
sudo chmod 777 $TEST/*
sudo rm $UPDATE/$FILE12
fi 
fi 

if [ -e $UPDATE/$FILE13 ]; then
DIF=0
DIF=`diff -c $UPDATE/$FILE13 $TEST/$FILE13`
if [ -z "$DIF" ] && [ -e $TEST/$FILE13 ] ; then
 sudo echo "same"
else
sudo cp $UPDATE/$FILE13 $TEST/$FILE13
sudo chmod 777 $TEST/*
sudo rm $UPDATE/$FILE13
fi 
fi 

if [ -e $UPDATE/$FILE14 ]; then
DIF=0
DIF=`diff -c $UPDATE/$FILE14 $TEST/$FILE14`
if [ -z "$DIF" ] && [ -e $TEST/$FILE14 ] ; then
 sudo echo "same"
else
sudo cp $UPDATE/$FILE14 $TEST/$FILE14
sudo chmod 777 $TEST/*
sudo rm $UPDATE/$FILE14
fi 
fi 

if [ -e $UPDATE/$FILE15 ]; then
DIF=0
DIF=`diff -c $UPDATE/$FILE15 $TEST/$FILE15`
if [ -z "$DIF" ] && [ -e $TEST/$FILE15 ] ; then
 sudo echo "same"
else
sudo cp $UPDATE/$FILE15 $TEST/$FILE15
sudo chmod 777 $TEST/*
sudo rm $UPDATE/$FILE15
fi 
fi 

if [ -e $UPDATE/$FILE16 ]; then
DIF=0
DIF=`diff -c $UPDATE/$FILE16 $TEST/$FILE16`
if [ -z "$DIF" ] && [ -e $TEST/$FILE16 ] ; then
 sudo echo "same"
else
sudo cp $UPDATE/$FILE16 $TEST/$FILE16
sudo chmod 777 $TEST/*
sudo rm $UPDATE/$FILE16
fi 
fi 

if [ -e $UPDATE/$FILE17 ]; then
DIF=0
DIF=`diff -c $UPDATE/$FILE17 $TEST/$FILE17`
if [ -z "$DIF" ] && [ -e $TEST/$FILE17 ] ; then
 sudo echo "same"
else
sudo cp $UPDATE/$FILE17 $TEST/$FILE17
sudo chmod 777 $TEST/*
sudo rm $UPDATE/$FILE17
fi 
fi 

if [ -e $UPDATE/$FILE18 ]; then
DIF=0
DIF=`diff -c $UPDATE/$FILE18 $TEST/$FILE18`
if [ -z "$DIF" ] && [ -e $TEST/$FILE18 ] ; then
 sudo echo "same"
else
sudo cp $UPDATE/$FILE18 $TEST/$FILE18
sudo chmod 777 $TEST/*
sudo rm $UPDATE/$FILE18
fi 
fi

if [ -e $UPDATE/$FILE19 ]; then
DIF=0
DIF=`diff -c $UPDATE/$FILE19 $TEST/$FILE19`
if [ -z "$DIF" ] && [ -e $TEST/$FILE19 ] ; then
 sudo echo "same"
else
sudo cp $UPDATE/$FILE19 $TEST/$FILE19
sudo chmod 777 $TEST/*
sudo rm $UPDATE/$FILE19
fi 
fi

if [ -e $UPDATE/$FILE20 ]; then
DIF=0
DIF=`diff -c $UPDATE/$FILE20 $TEST/$FILE20`
if [ -z "$DIF" ] && [ -e $TEST/$FILE20 ] ; then
 sudo echo "same"
else
sudo cp $UPDATE/$FILE20 $TEST/$FILE20
sudo chmod 777 $TEST/*
sudo rm $UPDATE/$FILE20
fi 
fi

if [ -e $UPDATE/$FILE21 ]; then
DIF=0
DIF=`diff -c $UPDATE/$FILE21 $TEST/$FILE21`
if [ -z "$DIF" ] && [ -e $TEST/$FILE21 ] ; then
 sudo echo "same"
else
sudo cp $UPDATE/$FILE21 $TEST/$FILE21
sudo chmod 777 $TEST/*
sudo rm $UPDATE/$FILE21
fi 
fi

if [ -e $UPDATE/$FILE22 ]; then
DIF=0
DIF=`diff -c $UPDATE/$FILE22 $TEST/$FILE22`
if [ -z "$DIF" ] && [ -e $TEST/$FILE22 ] ; then
 sudo echo "same"
else
sudo cp $UPDATE/$FILE22 $TEST/$FILE22
sudo chmod 777 $TEST/*
sudo rm $UPDATE/$FILE22
fi 
fi

if [ -e $UPDATE/$FILE23 ]; then
DIF=0
DIF=`diff -c $UPDATE/$FILE23 $TEST/$FILE23`
if [ -z "$DIF" ] && [ -e $TEST/$FILE23 ] ; then
 sudo echo "same"
else
sudo cp $UPDATE/$FILE23 $TEST/$FILE23
sudo chmod 777 $TEST/*
sudo rm $UPDATE/$FILE23
fi 
fi

echo "update.sh[test]" $(date +%T)


# cam folder (30~40)
if [ -e $UPDATE/$FILE30 ]; then
DIF=0
DIF=`diff -c $UPDATE/$FILE30 $CAM/$FILE30`
if [ -z "$DIF" ] && [ -e $CAM/$FILE30 ] ; then
 sudo echo "same"
else
sudo cp $UPDATE/$FILE30 $CAM/$FILE30
sudo chmod 777 $CAM/*
sudo rm $UPDATE/$FILE30
fi 
fi

# bt folder (41~)
if [ -e $UPDATE/$FILE41 ]; then
DIF=0
DIF=`diff -c $UPDATE/$FILE41 $BT/$FILE41`
if [ -z "$DIF" ] && [ -e $BT/$FILE41 ] ; then
 sudo echo "same"
else
sudo cp $UPDATE/$FILE41 $BT/$FILE41
sudo chmod 777 $BT/*
sudo rm $UPDATE/$FILE41
fi 
fi 


# PI folder 
if [ -e $UPDATE/$FILE45 ]; then
DIF=0
DIF=`diff -c $UPDATE/$FILE45 $PI/$FILE45`
if [ -z "$DIF" ] && [ -e $PI/$FILE45 ] ; then
 sudo echo "same"
else
sudo cp $UPDATE/$FILE45 $PI/$FILE45
sudo chmod 777 $PI/*
sudo rm $UPDATE/$FILE45
fi 
fi 

# Delete file 
#if [ -e $UPDATE/$FILE41 ]; then
#sudo chmod 777 $FILE41
#sudo rm $FILE41
#fi 

# www folder 
if [ -e $UPDATE/$FILE61 ]; then
DIF=0
DIF=`diff -c $UPDATE/$FILE61 $WWW/$FILE61`
if [ -z "$DIF" ] && [ -e $WWW/$FILE61 ] ; then
 sudo echo "same"
else
sudo cp $UPDATE/$FILE61 $WWW/$FILE61
sudo chmod 777 $WWW/*
sudo rm $UPDATE/$FILE61
fi 
fi 

# BTPUT bluetooth node folder (71~)
if [ -e $UPDATE/$FILE71 ]; then
DIF=0
DIF=`diff -c $UPDATE/$FILE71 $BTCEN/$FILE71`
if [ -z "$DIF" ] && [ -e $BTCEN/$FILE71 ] ; then
 sudo echo "same"
else
sudo cp $UPDATE/$FILE71 $BTCEN/$FILE71
sudo chmod 777 $BTCEN/*
sudo rm $UPDATE/$FILE71
fi 
fi 

if [ -e $UPDATE/$FILE72 ]; then
DIF=0
DIF=`diff -c $UPDATE/$FILE72 $BTCEN/$FILE72`
if [ -z "$DIF" ] && [ -e $BTCEN/$FILE72 ] ; then
 sudo echo "same"
else
sudo cp $UPDATE/$FILE72 $BTCEN/$FILE72
sudo chmod 777 $BTCEN/*
sudo rm $UPDATE/$FILE72
fi 
fi 

# bluetooth node folder for Peripheral (75~)
if [ -e $UPDATE/$FILE75 ]; then
DIF=0
DIF=`diff -c $UPDATE/$FILE75 $BTPER/$FILE75`
if [ -z "$DIF" ] && [ -e $BTPER/$FILE75 ] ; then
 sudo echo "same"
else
sudo cp $UPDATE/$FILE75 $BTPER/$FILE75
sudo chmod 777 $BTPER/*
sudo rm $UPDATE/$FILE75
fi 
fi 

if [ -e $UPDATE/$FILE76 ]; then
DIF=0
DIF=`diff -c $UPDATE/$FILE76 $BTPER/$FILE76`
if [ -z "$DIF" ] && [ -e $BTPER/$FILE76 ] ; then
 sudo echo "same"
else
sudo cp $UPDATE/$FILE76 $BTPER/$FILE76
sudo chmod 777 $BTPER/*
sudo rm $UPDATE/$FILE76
fi 
fi 

# ROOT 
if [ -e $UPDATE/$FILE80 ]; then
DIF=0
DIF=`diff -c $UPDATE/$FILE80 /$FILE80`
if [ -z "$DIF" ] && [ -e /$FILE80 ] ; then
 sudo echo "same"
else
sudo cp $UPDATE/$FILE80 /$FILE80
sudo chmod 777 /*
sudo rm $UPDATE/$FILE80
fi 
fi 

# run onetime  
if [ -e $UPDATE/$FILE90 ]; then
sudo cp $UPDATE/$FILE90 /$FILE90
sudo chmod 777 /*
sudo /$FILE90
sudo rm $UPDATE/$FILE90
fi 

sudo rm -rf $UPDATE/patch.zip

echo "update.sh[END]" $(date +%T)





