#!/bin/bash
#2023.02.16 PMK 

check=0
check=`sed -n '/SetPhaseCalW/{p;q}' /home/pi/test/GRadar_Info_wave.xml`
if [ -z "$check" ] ; then
 echo "there is not exist SetPhaseCalW[NONE]"
 sed -i '31s/^/    <SetPhaseCalW>0<\/SetPhaseCalW>\n/' /home/pi/test/GRadar_Info_wave.xml
else
 echo "there is exist SetPhaseCalW[value changed]"
 VAL=$1
 sudo sed -i "s/<SetPhaseCalW>.<\/SetPhaseCalW>/<SetPhaseCalW>$VAL<\/SetPhaseCalW>/g" /home/pi/test/GRadar_Info_wave.xml
 sudo sed -i "s/<SetPhaseCalW>..<\/SetPhaseCalW>/<SetPhaseCalW>$VAL<\/SetPhaseCalW>/g" /home/pi/test/GRadar_Info_wave.xml
 sudo sed -i "s/<SetPhaseCalW>...<\/SetPhaseCalW>/<SetPhaseCalW>$VAL<\/SetPhaseCalW>/g" /home/pi/test/GRadar_Info_wave.xml
 sudo sed -i "s/<SetPhaseCalW>....<\/SetPhaseCalW>/<SetPhaseCalW>$VAL<\/SetPhaseCalW>/g" /home/pi/test/GRadar_Info_wave.xml
 sudo sed -i "s/<SetPhaseCalW>.....<\/SetPhaseCalW>/<SetPhaseCalW>$VAL<\/SetPhaseCalW>/g" /home/pi/test/GRadar_Info_wave.xml
 
 sudo sed -i "s/<SetPhaseCalW>-.<\/SetPhaseCalW>/<SetPhaseCalW>$VAL<\/SetPhaseCalW>/g" /home/pi/test/GRadar_Info_wave.xml
 sudo sed -i "s/<SetPhaseCalW>-..<\/SetPhaseCalW>/<SetPhaseCalW>$VAL<\/SetPhaseCalW>/g" /home/pi/test/GRadar_Info_wave.xml 
 sudo sed -i "s/<SetPhaseCalW>-...<\/SetPhaseCalW>/<SetPhaseCalW>$VAL<\/SetPhaseCalW>/g" /home/pi/test/GRadar_Info_wave.xml  
 sudo sed -i "s/<SetPhaseCalW>-....<\/SetPhaseCalW>/<SetPhaseCalW>$VAL<\/SetPhaseCalW>/g" /home/pi/test/GRadar_Info_wave.xml 
 sudo sed -i "s/<SetPhaseCalW>-.....<\/SetPhaseCalW>/<SetPhaseCalW>$VAL<\/SetPhaseCalW>/g" /home/pi/test/GRadar_Info_wave.xml 
 
 sudo sed -i "s/<SetPhaseCalW>.<\/SetPhaseCalW>/<SetPhaseCalW>$VAL<\/SetPhaseCalW>/g" /GRadar_Info.xml
 sudo sed -i "s/<SetPhaseCalW>..<\/SetPhaseCalW>/<SetPhaseCalW>$VAL<\/SetPhaseCalW>/g" /GRadar_Info.xml
 sudo sed -i "s/<SetPhaseCalW>...<\/SetPhaseCalW>/<SetPhaseCalW>$VAL<\/SetPhaseCalW>/g" /GRadar_Info.xml
 sudo sed -i "s/<SetPhaseCalW>....<\/SetPhaseCalW>/<SetPhaseCalW>$VAL<\/SetPhaseCalW>/g" /GRadar_Info.xml
 sudo sed -i "s/<SetPhaseCalW>.....<\/SetPhaseCalW>/<SetPhaseCalW>$VAL<\/SetPhaseCalW>/g" /GRadar_Info.xml 
 
 
 sudo sed -i "s/<SetPhaseCalW>-.<\/SetPhaseCalW>/<SetPhaseCalW>$VAL<\/SetPhaseCalW>/g" /GRadar_Info.xml
 sudo sed -i "s/<SetPhaseCalW>-..<\/SetPhaseCalW>/<SetPhaseCalW>$VAL<\/SetPhaseCalW>/g" /GRadar_Info.xml
 sudo sed -i "s/<SetPhaseCalW>-...<\/SetPhaseCalW>/<SetPhaseCalW>$VAL<\/SetPhaseCalW>/g" /GRadar_Info.xml
 sudo sed -i "s/<SetPhaseCalW>-....<\/SetPhaseCalW>/<SetPhaseCalW>$VAL<\/SetPhaseCalW>/g" /GRadar_Info.xml
 sudo sed -i "s/<SetPhaseCalW>-.....<\/SetPhaseCalW>/<SetPhaseCalW>$VAL<\/SetPhaseCalW>/g" /GRadar_Info.xml 
fi

check=0
check=`sed -n '/SetPhaseCalH/{p;q}' /home/pi/test/GRadar_Info_wave.xml`
if [ -z "$check" ] ; then
 echo "there is not exist SetPhaseCalH[NONE]"
 sed -i '32s/^/    <SetPhaseCalH>0<\/SetPhaseCalH>\n/' /home/pi/test/GRadar_Info_wave.xml
else
 echo "there is exist SetPhaseCalH[value changed]"
 VAL=$2
 sudo sed -i "s/<SetPhaseCalH>.<\/SetPhaseCalH>/<SetPhaseCalH>$VAL<\/SetPhaseCalH>/g" /home/pi/test/GRadar_Info_wave.xml
 sudo sed -i "s/<SetPhaseCalH>..<\/SetPhaseCalH>/<SetPhaseCalH>$VAL<\/SetPhaseCalH>/g" /home/pi/test/GRadar_Info_wave.xml
 sudo sed -i "s/<SetPhaseCalH>...<\/SetPhaseCalH>/<SetPhaseCalH>$VAL<\/SetPhaseCalH>/g" /home/pi/test/GRadar_Info_wave.xml
 sudo sed -i "s/<SetPhaseCalH>....<\/SetPhaseCalH>/<SetPhaseCalH>$VAL<\/SetPhaseCalH>/g" /home/pi/test/GRadar_Info_wave.xml
 sudo sed -i "s/<SetPhaseCalH>.....<\/SetPhaseCalH>/<SetPhaseCalH>$VAL<\/SetPhaseCalH>/g" /home/pi/test/GRadar_Info_wave.xml 
 
 sudo sed -i "s/<SetPhaseCalH>-.<\/SetPhaseCalH>/<SetPhaseCalH>$VAL<\/SetPhaseCalH>/g" /home/pi/test/GRadar_Info_wave.xml
 sudo sed -i "s/<SetPhaseCalH>-..<\/SetPhaseCalH>/<SetPhaseCalH>$VAL<\/SetPhaseCalH>/g" /home/pi/test/GRadar_Info_wave.xml 
 sudo sed -i "s/<SetPhaseCalH>-...<\/SetPhaseCalH>/<SetPhaseCalH>$VAL<\/SetPhaseCalH>/g" /home/pi/test/GRadar_Info_wave.xml 
 sudo sed -i "s/<SetPhaseCalH>-....<\/SetPhaseCalH>/<SetPhaseCalH>$VAL<\/SetPhaseCalH>/g" /home/pi/test/GRadar_Info_wave.xml  
 sudo sed -i "s/<SetPhaseCalH>-.....<\/SetPhaseCalH>/<SetPhaseCalH>$VAL<\/SetPhaseCalH>/g" /home/pi/test/GRadar_Info_wave.xml 

 
 sudo sed -i "s/<SetPhaseCalH>.<\/SetPhaseCalH>/<SetPhaseCalH>$VAL<\/SetPhaseCalH>/g" /GRadar_Info.xml
 sudo sed -i "s/<SetPhaseCalH>..<\/SetPhaseCalH>/<SetPhaseCalH>$VAL<\/SetPhaseCalH>/g" /GRadar_Info.xml
 sudo sed -i "s/<SetPhaseCalH>...<\/SetPhaseCalH>/<SetPhaseCalH>$VAL<\/SetPhaseCalH>/g" /GRadar_Info.xml
 sudo sed -i "s/<SetPhaseCalH>....<\/SetPhaseCalH>/<SetPhaseCalH>$VAL<\/SetPhaseCalH>/g" /GRadar_Info.xml
 sudo sed -i "s/<SetPhaseCalH>.....<\/SetPhaseCalH>/<SetPhaseCalH>$VAL<\/SetPhaseCalH>/g" /GRadar_Info.xml 
 
 sudo sed -i "s/<SetPhaseCalH>-.<\/SetPhaseCalH>/<SetPhaseCalH>$VAL<\/SetPhaseCalH>/g" /GRadar_Info.xml
 sudo sed -i "s/<SetPhaseCalH>-..<\/SetPhaseCalH>/<SetPhaseCalH>$VAL<\/SetPhaseCalH>/g" /GRadar_Info.xml
 sudo sed -i "s/<SetPhaseCalH>-...<\/SetPhaseCalH>/<SetPhaseCalH>$VAL<\/SetPhaseCalH>/g" /GRadar_Info.xml
 sudo sed -i "s/<SetPhaseCalH>-....<\/SetPhaseCalH>/<SetPhaseCalH>$VAL<\/SetPhaseCalH>/g" /GRadar_Info.xml
 sudo sed -i "s/<SetPhaseCalH>-.....<\/SetPhaseCalH>/<SetPhaseCalH>$VAL<\/SetPhaseCalH>/g" /GRadar_Info.xml 
fi


#VAL=$1
#sudo sed -i "s/<SetPhaseCalW>.<\/SetPhaseCalW>/<SetPhaseCalW>$VAL<\/SetPhaseCalW>/g" /home/pi/test/GRadar_Info_wave.xml
#sudo sed -i "s/<SetPhaseCalW>..<\/SetPhaseCalW>/<SetPhaseCalW>$VAL<\/SetPhaseCalW>/g" /home/pi/test/GRadar_Info_wave.xml

#VAL=$2
#sudo sed -i "s/<SetPhaseCalH>.<\/SetPhaseCalH>/<SetPhaseCalH>$VAL<\/SetPhaseCalH>/g" /home/pi/test/GRadar_Info_wave.xml
#sudo sed -i "s/<SetPhaseCalH>..<\/SetPhaseCalH>/<SetPhaseCalH>$VAL<\/SetPhaseCalH>/g" /home/pi/test/GRadar_Info_wave.xml
