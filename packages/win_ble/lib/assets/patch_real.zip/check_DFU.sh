#!/bin/bash
# golfzon PMK

COUNT1=0
UNTIL=5

# STEP1 : Wait 5 second until detect STM DUT  
while [ $COUNT1 -ne $UNTIL ]
 do 
  USBis=`lsusb | grep -i "DFU" | gawk -F" " '{printf $8}'`    
  if [ "$USBis" == "STM" ]; then
   VEN=`lsusb | grep -i "STM" | gawk -F" " '{printf $6}' | gawk -F":" '{print $1}'`
   PRO=`lsusb | grep -i "STM" | gawk -F" " '{printf $6}' | gawk -F":" '{print $2}'`
   if [ "$VEN" == "0483" ] && [ "$PRO" == "df11" ]; then
    COUNT1=10
    echo "Check ... STM is in DFU Mode"
	CHECK=0
    CHECK=`dfu-prefix -c /home/pi/test/DBfirmware.dfu|grep "Product ID"|gawk -F" " '{print $3}'`
    if [ -z "$CHECK" ]; then
     echo "DBfirmware is not valid"
    else
     echo "DBfirmware is valid"
     sudo dfu-util -a 0 -D /home/pi/test/DBfirmware.dfu | tee /home/pi/test/fw_down.log
	 sleep 7
     # check finished 
     sudo /home/pi/test/check_fw_finish.sh 	
     echo "DB Reset!!!" 
     sudo /home/pi/test/db_hwrst
     sudo /home/pi/test/usb_reset.sh	
     exit 0
	fi 
   fi
  else
   COUNT1=$(($COUNT1+1)) 
   echo "[check_DFU]Check STM DUT[$COUNT1]"
  fi 
 sleep 0.5
 done 
