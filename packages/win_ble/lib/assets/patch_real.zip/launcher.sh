#!/bin/sh

DGFW=/home/upgrade/DigitalBoard/DBfirmware.dfu
PATCH=/home/upgrade/GRadar_DLL/update.sh
PATCH_ZIP=/home/upgrade/GRadar_DLL/patch.zip
UPDATE=/home/upgrade/GRadar_DLL
UPDATA_FW=/home/upgrade/GRadar_DLL/DBfirmware.dfu
FWFOLDER=/home/upgrade/DigitalBoard

#Radar Mini (RST pin high)
sudo gpio write 1 1
sleep 1

#begin log backup
#for i in 19 18 17 16 15 14 13 12 11 10 9 8 7 6 5 4 3 2 1 
#for i in 13 12 11 10 9 8 7 6 5 4 3 2 1
#for i in 8 7 6 5 4 3 2 1
for i in 5 4 3 2 1
do
	offset=1
before=`expr $i - $offset`
sudo rm -rf /home/dbgftp/BT_Log$i
sudo rm -rf /home/dbgftp/Result$i
sudo rm -rf /home/dbgftp/ShotDB$i
sudo rm -rf /home/dbgftp/Log$i

sudo mv /home/dbgftp/BT_Log$before /home/dbgftp/BT_Log$i
sudo mv /home/dbgftp/Result$before /home/dbgftp/Result$i
sudo mv /home/dbgftp/ShotDB$before /home/dbgftp/ShotDB$i
sudo mv /home/dbgftp/Log$before /home/dbgftp/Log$i
done

sudo mv /home/dbgftp/BT_Log /home/dbgftp/BT_Log1
sudo mv /home/dbgftp/Log /home/dbgftp/Log1
sudo mv /home/dbgftp/Result /home/dbgftp/Result1
sudo mv /home/dbgftp/ShotDB /home/dbgftp/ShotDB1

sudo mkdir /home/dbgftp/BT_Log
sudo mkdir /home/dbgftp/Log
sudo mkdir /home/dbgftp/Result
sudo mkdir /home/dbgftp/ShotDB
#end log backup

#set cpu max freq
sudo /home/pi/test/cpu_max.sh
#sleep 1

#selflog 
sudo /home/pi/test/rm_selflog.sh &
sleep 1 

#log 
sudo /home/pi/test/rm_log.sh &
sudo /home/pi/test/zip_log.sh &
sleep 1 

#mk tar shotdb1 and del *.rbf 
sudo /home/pi/test/rm_rbf.sh &
sudo /home/pi/test/zip_rbf.sh &
sleep 1 

#mk tar result1 and del *.jpg
sudo /home/pi/test/rm_jpg.sh &
sudo /home/pi/test/zip_jpg.sh &
sleep 1 

#rm bt_check log
sudo /home/pi/bt/rm_bt.sh  
sleep 1 

sudo NetworkManager off
sleep 1
sudo rm -rf /home/pi/hostapd.conf
sleep 1
#if [ -f "/home/pi/hostapd.conf" ] ; then
#	echo "setting complete"
#else
	touch /home/pi/hostapd.conf
	sleep 1 
	sudo echo "interface=wlan0" >> /home/pi/hostapd.conf
	sudo echo "driver=nl80211" >> /home/pi/hostapd.conf
    sudo echo -n "ssid=WAVE_" >>/home/pi/hostapd.conf
    #sudo echo `cat /sys/class/net/wlan0/address | cut -c 7-19`>>/home/pi/hostapd.conf
    #sudo echo `cat /sys/class/net/wlan0/address | cut -c 13-19`>>/home/pi/hostapd.conf
	#sudo echo `cat /sys/class/net/wlan0/address|sed 's/://g'`>>/home/pi/hostapd.conf
	#sudo echo `cat /sys/class/net/wlan0/address|cut -c 7-19|sed 's/://g'`>>/home/pi/hostapd.conf 
	MAC=`sudo cat /sys/class/net/wlan0/address|cut -c 7-19|sed 's/://g'`
	MAC=`sudo echo $MAC | tr '[:lower:]' '[:upper:]'`
	sudo echo  $MAC >>/home/pi/hostapd.conf
	sudo echo "hw_mode=g" >> /home/pi/hostapd.conf
	sudo echo "channel=7" >> /home/pi/hostapd.conf
    sudo echo "ignore_broadcast_ssid=0" >> /home/pi/hostapd.conf
	sudo echo "auth_algs=1" >> /home/pi/hostapd.conf
	sudo echo "wpa=2" >> /home/pi/hostapd.conf
	sudo echo "wpa_key_mgmt=WPA-PSK" >> /home/pi/hostapd.conf
	sudo echo "rsn_pairwise=CCMP" >> /home/pi/hostapd.conf
	sudo echo -n "wpa_passphrase=" >>/home/pi/hostapd.conf
	#sudo echo `cat /sys/class/net/wlan0/address  | gawk -F: '{print $3$4$5$6$7}'` >>/home/pi/hostapd.conf
	#sudo echo `cat /sys/class/net/wlan0/address  | gawk -F: '{print $5$6}'` >>/home/pi/hostapd.conf
	sudo echo "wave1234"  >>/home/pi/hostapd.conf
#fi
sudo ifconfig wlan0 192.168.8.1 netmask 255.255.255.0
sleep 1 
sudo udhcpd -f /etc/udhcpd.conf &
sleep 1
sudo hostapd -B /home/pi/hostapd.conf
sleep 1

# 2022.11.02 PMK 
echo "update PATCH_ZIP(others) ------"
if [ -f "$PATCH_ZIP" ] ; then
 CHECK=0
 CHECK=`unzip -t -P "GOLFZONWAVE" $PATCH_ZIP | grep "No errors"|gawk -F" " '{print $1$2}'`
 if [ -z "$CHECK" ]; then
  echo "patch.zip is not valid"
  sudo rm -rf $UPDATE/patch.zip
 else
  echo "patch.zip is valid"
  sudo chmod 777 /home/upgrade/GRadar_DLL/*
  sudo unzip -P "GOLFZONWAVE" $UPDATE/patch.zip -d  $UPDATE/
  sleep 1 
  sudo chmod 777 /home/upgrade/GRadar_DLL/*	
  sudo rm -rf $UPDATE/patch.zip
  #sudo /home/upgrade/GRadar_DLL/update.sh 
  #sleep 10
  #sudo rm -rf /home/upgrade/GRadar_DLL/update.sh
 fi 	
else
    echo "update PATCH_ZIP nothing\n"
fi
sleep 1 

# 2021.11.18 PMK, 
if [ -f "$PATCH" ] ; then
    sudo chmod 777 /home/upgrade/GRadar_DLL/*
	sudo /home/upgrade/GRadar_DLL/update.sh 
	sleep 10
    sudo rm -rf /home/upgrade/GRadar_DLL/update.sh
else
    echo "update patch nothing\n"
	fi
sleep 1 

# DigitalBd FW DOWNLOAD 
if [ -f "$UPDATA_FW" ] ; then
 CHECK=0
 CHECK=`dfu-prefix -c $UPDATE/DBfirmware.dfu|grep "Product ID"|gawk -F" " '{print $3}'`
 if [ -z "$CHECK" ]; then
  echo "DBfirmware is not valid"
 else
  echo "DBfirmware is valid"
  sudo mv $UPDATE/DBfirmware.dfu $FWFOLDER/
  sleep 1
  DIF=0
  DIF=`diff -c /home/pi/test/DBfirmware.dfu /home/upgrade/DigitalBoard/DBfirmware.dfu`
  if [ -z "$DIF" ] && [ -e /home/pi/test/DBfirmware.dfu ] ; then
   echo "DBfirmware is same" 
   rm -rf /home/upgrade/DigitalBoard/DBfirmware.dfu
  else
   echo "DBfirmware is not same" 
   sudo /home/pi/test/fw_down.sh $DGFW
   sleep 3
  fi 
 fi 
else 
  echo "DBfirmware is not exit"
  rm -rf /home/upgrade/DigitalBoard/DBfirmware.dfu
fi 

echo "update version(DLL) ------------------------------------------" 
sudo /home/pi/GRadarM/DLLUpdater.sh
sudo /home/pi/test/DT_up.sh 
echo "update version end---------------------------------------" 
sleep 2

# check DLL 
sudo echo "check DLL"
sudo /home/pi/test/check_DLL.sh 
sleep 2 

# check it DFU mode is in still 
sudo echo "check DFU"
sudo /home/pi/test/check_DFU.sh 

sudo echo "check E6"
sudo /home/pi/test/check_E6.sh

# delete UPDATE FOLDER FILES 
sudo rm -rf $UPDATE/*.*

sleep 1 
sudo /home/pi/test/detect_eth.sh

sudo /home/pi/test/wifi_autoch_1.sh
sleep 1 

#set cpu max freq 
sudo /home/pi/test/cpu_max.sh

#set temp
sudo echo 130000 > /sys/class/thermal/thermal_zone0/trip_point_3_temp
sudo echo "temp critical changed"
sudo cat /sys/class/thermal/thermal_zone0/trip_point_3_temp


#bt address change to match wifi mac 
sudo /home/pi/bt/bt_mac_1.sh 
sleep 1 

# rf power changed(default:31) : (RF Compliance :13) 
sudo iwconfig wlan0 txpower 31

# E6 PC Clinet 
sudo /home/pi/test/e6/E6Client &

sudo /home/pi/test/run_check_gradar.sh 
#sudo /home/pi/test/run_check_gradar_e.sh
